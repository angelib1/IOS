//
//  BIDDraw.h
//  Exersice8
//
//  Created by Nguyen Thanh Son on 5/22/13.
//  Copyright (c) 2013 Nguyen Thanh Son. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDDraw : UIView

@end
