//
//  BIDAddCell.h
//  Exersice11
//
//  Created by Nguyen Thanh Son on 8/1/13.
//  Copyright (c) 2013 Nguyen Thanh Son. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDAddCell : UITableViewCell
@property (strong, nonatomic) UILabel *Label;
@property (strong, nonatomic) UILabel *subLabel;
@property (strong, nonatomic) UILabel *subLabelInfo;
@property (strong, nonatomic) UIImageView *image;

@end
