//
//  BIDAddCell.h
//  Exercise11_1
//
//  Created by Nguyen Thanh Son on 8/5/13.
//  Copyright (c) 2013 Nguyen Thanh Son. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDAddCell : UITableViewCell
@property (strong, nonatomic) UILabel *Label;
@end
